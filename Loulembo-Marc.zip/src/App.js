
import './App.css';
import TodoList from './components/todo-list/Todo-list';
import Todolist from "./components/todo-list/Todolist.css";



function App() {
  return (
    <TodoList/>
  );
}

export default App;
